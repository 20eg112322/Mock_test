package com.example.shipment_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShipmentManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
