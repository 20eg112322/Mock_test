package com.example.curtainmodel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CurtainManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(CurtainManagementApplication.class, args);
	}

}
