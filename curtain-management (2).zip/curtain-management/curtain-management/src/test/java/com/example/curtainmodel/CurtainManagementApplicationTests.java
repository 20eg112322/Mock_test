package com.example.curtainmodel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurtainManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
